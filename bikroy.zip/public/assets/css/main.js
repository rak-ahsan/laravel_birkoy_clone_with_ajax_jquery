// search on click

$('#loc').click(function(){
    $('.hide').css('display', 'block');
});