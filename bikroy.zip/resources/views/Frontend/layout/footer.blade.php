<hr style="  border: 1px solid green;">
<div class="container">
    <div class="row">
        <div class="col-md-4 mb-2">
            <div class="play mx-2 d-flex">
              <a href="">  <img src={{asset('img/play.png')}} alt="" srcset="" style="border-radius: 10px; height:50px;width:150px"></a>
               <a href=""> <img src={{asset('img/apple.png')}} alt="" srcset="" style="border-radius: 10px; height:50px;width:150px"></a>
            </div>
            <div class="mt-3">
                <b>Connect WIth Us</b> <br> 
                <i class="fa-brands fa-square-facebook"></i> <b>Like us on facebook</b>
            </div>
            <div class="mt-3">
                <b>Other Countries</b> <br> 
                 <a href="#" class="nav-link text-info"> Srilanka</a>
            </div>
        </div>
        <div class="col-md-8 d-flex justify-content-between">
            <div class="f1 mb-3">
                <b>More from Bikroy</b><br>
                <a class="nav-link" href="#">Sell Fast</a>
                <a class="nav-link" href="#">Membership</a>
                <a class="nav-link" href="#">Banner Ads</a>
                <a class="nav-link" href="#">Ad Promotions</a>
            </div>
            <div class="f1 mb-3">
                <b>Help & Support</b><br>
                <a class="nav-link" href="#">FAQ</a>
                <a class="nav-link" href="#">Stay safe</a>
                <a class="nav-link" href="#">Contact Us</a>
            </div>
            <div class="f1 mb-3">
                <b>Follow Bikroy</b><br>
                <a class="nav-link" href="#">Blog</a>
                <a class="nav-link" href="#">Facebook</a>
                <a class="nav-link" href="#">Twitter</a>
                <a class="nav-link" href="#">Youtube</a>
            </div>
            <div class="f1 mb-3">
                <b>About Bikroy</b><br>
                <a class="nav-link" href="#">About Us</a>
                <a class="nav-link" href="#">Careers</a>
                <a class="nav-link" href="#">Terms and Conditions</a>
                <a class="nav-link" href="#">Privacy policy</a>
                <a class="nav-link" href="#">Sitemap</a>
            </div>
        </div>
        <hr>
    </div>
</div>
<div class="container">
        <div class="row d-flex justify-content-between mb-3 align-items-center">
            <div class="col-md-6"><span>Copyright © Saltside Technologies</span></div>
            <div class="col-md-6 text-end"><img src="logo.png" alt="" srcset="" style="height:40px;border-radius:10px"></div>
        </div>
</div>