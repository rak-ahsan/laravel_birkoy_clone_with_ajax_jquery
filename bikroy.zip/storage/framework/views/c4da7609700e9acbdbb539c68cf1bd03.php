<?php $__env->startSection('content'); ?>
<div class="container shadow mt-5" style="background-color: #FFFFFF">
    <div class="row">
        <div class="col-md-2 p-3" style="border-right: 1px solid rgb(200, 200, 200)">
        <a href="<?php echo e(route('userads')); ?>" class="nav-link">My Ads</a>
        <a href="<?php echo e(route('saveads')); ?>" class="nav-link">Saved Ads</a>
        <a href="<?php echo e(route('profile.edit')); ?>" class="nav-link">Update Profile</a>
        </div>
        <!-- mainpart -->
        <div class="col-md-10 p-3">
            <?php echo $__env->yieldContent('profile'); ?>
        </div>
    </div>
</div>

<?php echo $__env->make('Frontend/layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layout.Head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/rakib/SSD/bikroy/resources/views/Frontend/layout/profilesettings.blade.php ENDPATH**/ ?>