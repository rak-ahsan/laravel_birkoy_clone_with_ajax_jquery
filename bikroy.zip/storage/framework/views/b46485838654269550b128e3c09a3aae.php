
<?php $__env->startSection('content'); ?>
<div class="container shadow" style="background-color: #FFFFFF">
    <div class="row mt-5 border-bottom ">
        <div class="part1 justify-content-center align-items-center d-flex mt-4 row">
            <div class="col-md-4">
                <p style="font-size: 15px" id="loc"> <i class="fa-solid fa-location-dot fa-xl"
                        style="color: #149777;"></i> <b>Select Location</b></p>
            </div>
            <div class="col-md-4">
                <p style="font-size: 15px"> <i class="fa-solid fa-tag fa-rotate-90 fa-xl"
                        style="color: #149777;"></i><b>Select Category</b></p>
            </div>
            <div class="col-md-4 d-sm-none d-md-block">
                <div class="search">
                    <form class="d-flex align-items-center justify-content-center" role="search" action="3"
                        method="GET">
                        <input class="form-control me-2" type="search" placeholder="What Are You Looking For?"
                            aria-label="Search" name="query" style="border-radius: 30px">
                        <button type="submit" class="btn"
                            style="background-color: transparent; border: none; margin-left: -80px;">
                            <i class="fa-solid fa-magnifying-glass fa-2xl"
                                style="color: #000000; border-radius:20px"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4" style="border-right: 1px solid rgb(200, 200, 200)">
            <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $catagory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <a href="<?php echo e(url ('category/'.$list->cata_id )); ?>" class="nav-link">
                        <i class="<?php echo e($list->cata_icon); ?>" style="margin-right:10px;"></i> <?php echo e($list->cata_name); ?>

                    </a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
            <?php echo e($catagory->links()); ?>

        </div>
        <div class="col-md-8 p-3">
            <div class="post">

                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <a href="<?php echo e(url('productview/' . $list->ads_id)); ?>" class="nav-link">
                    <div class="card my-3">
                        <div class="row g-0 p-3">
                            <div class="col-md-4">
                                <img src="<?php echo e(asset('img/ads/' . $list->mainphoto)); ?>" class="img-fluid rounded-start"
                                    alt="..." style="height: 200px">
                              </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <?php echo e($list->title); ?></h5>
                                    <p class="card-text"> <?php echo e($list->loc_name); ?> , <?php echo e($list->cata_name); ?></p>
                                    <p class="card-text"><span style="color: #149777; font-size:20px ">Tk
                                            <?php echo e($list->price); ?></span></p>
                                </div>
                                <p class="text-end px-4"><?php echo \Carbon\Carbon::parse($list->created_at)->diffForHumans(); ?></p>
                            </div>
                        </div>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        </div>
    </div>

    <?php echo $__env->make('Frontend/layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layout.Head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bikroy\resources\views/Frontend/layout/browsbycata.blade.php ENDPATH**/ ?>