<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(Auth::user()->username == $ads->user_name): ?>
    <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('upads', ['ads_id' => $ads->ads_id])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div class="row">
            <div class="formdesign mt-4 p-3" style="background-color: #fff">
                <div class="top col-md-12 d-flex justify-content-between">
                    <div class="top-f col-md-4">
                        <b>Fill in the details</b>
                    </div>
                    <div class="top-f col-md-3 text-center">
                        <select class="form-select form-select-sm" aria-label="Small select example" name='ads_loc'
                            id="search">
                            <option value="">Please Select Location</option>
                            <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($row->loc_id); ?>" <?php echo e($ads->ads_loc == $row->loc_id ? 'selected' : ''); ?>>
                                <?php echo e($row->loc_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['ads_loc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="invalid-feedback d-block">Location Is Requried</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="top-f col-md-3 text-center">
                        <select class="form-select form-select-sm text-start" aria-label="Small select example"
                            name='ads_cata' id="cata">
                            <option value="">Please Select Catagories</option>
                            <?php $__currentLoopData = $catagory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($row->cata_id); ?>" <?php echo e($ads->ads_cata == $row->cata_id ? 'selected' : ''); ?>>
                                <?php echo e($row->cata_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['ads_cata'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="invalid-feedback d-block">Catagories Is Requried</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
        </div>
        <hr>
        <div class="row" style="background-color: #fff">
            <div class="top-f  d-flex justify-content-around align-items-center">
                <div class="col-md-6">
                    <label for="" class="text-end fw-bolder mt-5">Product Availability</label>
                    <select class="form-select form-select-sm mt-3" aria-label="Small select example" name='availability'
                            id="search">
                            <option value="">Please Select Availability</option>
                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($row->status_id); ?>" <?php echo e($ads->availability == $row->status_id ? 'selected' : ''); ?>>
                                <?php echo e($row->status_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['availability'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="invalid-feedback d-block">Availability Is Requried</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

            </div>

            <div class="top-f  d-flex justify-content-around align-items-center mb-5">
                <div class="col-md-6">
                    <label for="" class="text-end fw-bolder mt-5">Post Title</label>
                    <input type="text" class="form-control" id="inputPassword2" placeholder="title" name='title'
                    value="<?php echo e($ads->title); ?>">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="invalid-feedback d-block text-center">Title Is Required</p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <label for="" class="text-center fw-bolder mt-3">Conditions</label>
            <div class="main d-flex justify-content-around align-items-center">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="condtions" id="flexRadioDefault1" value="used" <?php echo e($ads->condtions=='used' ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="flexRadioDefault1">
                        Used
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="condtions" id="flexRadioDefault2" value="new" <?php echo e($ads->condtions=='new' ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="flexRadioDefault2">
                        New
                    </label>
                </div>
            </div>
            <?php $__errorArgs = ['condtions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="invalid-feedback d-block text-center"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label for="" class="text-center fw-bolder mt-5">Authenticity</label>
            <div class="main d-flex justify-content-around">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="authenticity" id="flexRadioDefault3"
                        value="orginal" <?php echo e($ads->authenticity=='orginal' ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="flexRadioDefault3">
                        Original
                    </label>
                </div>

                <div class="form-check">
                    <input class="form-check-input" type="radio" name="authenticity" id="flexRadioDefault4"
                        value="refurbished" <?php echo e($ads->authenticity=='refurbished' ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="flexRadioDefault4">
                        Refurbished
                    </label>
                </div>
            </div>
            <?php $__errorArgs = ['authenticity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="invalid-feedback d-block text-center">Authenticity Is Required</p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="top-f  d-flex justify-content-around align-items-center mb-5">
                <div class="col-md-6">
                    <label for="" class="text-end fw-bolder mt-5">Brand</label>
                    <input type="text" class="form-control" id="inputPassword2" placeholder="Brand" name="brand"
                        value="<?php echo e($ads->brand); ?>">
                </div>
            </div>
            <?php $__errorArgs = ['authenticity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="invalid-feedback d-block text-center">Brand Is Required</p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="top-f  d-flex justify-content-around align-items-center mb-5">
                <div class="col-md-6">
                    <label for="" class="text-end fw-bolder mt-3">Model</label>
                    <input type="text" class="form-control" id="inputPassword2" placeholder="Model" name="model"
                        value="<?php echo e($ads->model); ?>">
                </div>
            </div>
            <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="invalid-feedback d-block text-center">Model Is Required</p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="form-floating d-flex justify-content-around align-items-center mb-5">
                <div class="col-md-6">
                    <label for="" class="text-end fw-bolder mt-3">Product Description</label>
                    <textarea class="form-control" placeholder="Enter Description" id="floatingTextarea2"
                        style="height: 100px" name="desc">
                      <?php echo e(trim($ads->desc)); ?>

                    </textarea>
                </div>
            </div>
            <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="invalid-feedback d-block text-center">Product Description Is Required</p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="form-floating d-flex justify-content-around align-items-center mb-5">
                <div class="col-md-6">
                    <label for="" class="text-end fw-bolder mt-3">Product Price</label>
                    <input type="text" class="form-control" id="inputPassword2" placeholder="Price" name="price" value="<?php echo e($ads->price); ?>">
                </div>
            </div>
            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="invalid-feedback d-block text-center">Product Price Is Required</p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="form-floating d-flex justify-content-around align-items-center mb-5">
                <div class="col-md-6">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault"
                            name="nego" <?php echo e($ads->nego=='on' ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="flexSwitchCheckDefault">Negotiable</label>
                    </div>
                </div>
            </div>
            <hr>
            
            <div class="form-floating d-flex justify-content-around align-items-center mb-5">
                <div class="col-md-6">
                    <h6>Contact details</h6>
                    <div class="">
                        <label for="" class="text-end fw-bolder mt-3">Name</label>
                        <input type="text" readonly class="form-control-plaintext" id="staticEmail"
                            value="<?php echo e(Auth::user()->name); ?>">
                    </div>
                    <div class="">
                        <label for="" class="text-end fw-bolder mt-3">Email</label>
                        <input type="text" readonly class="form-control-plaintext" id="staticEmail"
                            value="<?php echo e(Auth::user()->email); ?>">
                    </div>
                    <div class="">
                        <label for="" class="text-end fw-bolder mt-3">Number</label>
                        <div class="col-sm-10">
                            <input type="number" class="form-control" id="inputPassword" name="pos_number"
                                value="<?php echo e($ads->pos_number); ?>">
                            <input type="hidden" class="form-control" id="inputPassword" name="user_name"
                                value="<?php echo e(Auth::user()->username); ?>">
                            <input type="hidden" value="3" name="ads_status">
                        </div>
                    </div>
                    <?php $__errorArgs = ['pos_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="invalid-feedback d-block text-center">Number Is Required</p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="mt-3">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckIndeterminate">
                        <label class="form-check-label" for="flexCheckIndeterminate">
                            I have read and accept the Terms and Conditions </label>
                    </div>
                    
                    <div class="mt-3 text-end">
                        <button type="submit" class="btn btn-success px-5">Update ad</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <?php else: ?>
    <span>Access Dinied</span>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('Frontend.layout.Head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/rakib/SSD/bikroy/resources/views/Frontend/useradsedit.blade.php ENDPATH**/ ?>