 
<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="container mb-5">
        <ul id="chat">
            <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($chat->sender == Auth::user()->username): ?>
                    <li class="me">
                        <div class="entete">
                            <h3><?php echo e($chat->created_at->timezone('Asia/Dhaka')->format('h:iA, M d')); ?></h3>
                            <h2>Me</h2><span class="status blue"></span>
                        </div>
                        <div class="message"><?php echo e($chat->message); ?></div>
                    </li>
                <?php else: ?>
                <?php if($chat->sender == $sender && $chat->reciver == Auth::user()->username): ?>
                    <li class="you">
                        <div class="entete"><span class="status green"></span>
                            <h2><?php echo e($chat->sender); ?></h2>
                            <h3><?php echo e($chat->created_at->setTimezone('Asia/Dhaka')->format('h:iA, M d')); ?></h3>
                        </div>
                        
                        <div class="message"><?php echo e($chat->message); ?> </div>
                    </li>
                <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php if($chat->availability==1): ?>
        
        <form action="<?php echo e(route('chatstore')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="col-md-12">
                <textarea class="form-control" placeholder="Enter Message" id="floatingTextarea2"
                    style="height: 100px" name="message"></textarea>
                
                <input type="hidden" value="<?php echo e($sender); ?>" name="reciver">
                
                
                
                <input type="hidden" value="<?php echo e(Auth::user()->username); ?>" name="sender">
                <input type="hidden" value="<?php echo e($chat->product_id); ?>" name="product_id">
            </div>
            <div class="mt-3 text-end">
                <button type="submit" class="btn btn-success px-5">Send Message</button>
            </div>
        </form>

        <?php else: ?>
            <b>Product Sold Out </b>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layout.Head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bikroy\resources\views/Frontend/messenger.blade.php ENDPATH**/ ?>