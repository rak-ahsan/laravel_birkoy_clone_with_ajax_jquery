
<?php $__env->startSection('content'); ?>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">All Ads</h4>
            </p>
            <table class="table table-bordered text-center">
                <thead>
                    <tr>
                        <th> # </th>
                        <th> reports Details </th>
                        <th> Ads Title </th>
                        <th> Status </th>
                        <th> Reporting Date </th>
                        <th colspan="3"> Action </th>
                    </tr>
                </thead>
                <?php
                $a=1
                ?>
                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($a++); ?> </td>
                    <td> <?php echo e($list->reports); ?></td>
                    <td><?php echo e($list->title); ?> </td>
                    <?php if($list->status==0): ?>
                    <td> Pending </td>
                    <?php else: ?>
                    <td> Resolved </td>
                    <?php endif; ?>
                    <td><?php echo e($list->created_at); ?> </td>
                    <td><a href="<?php echo e(url('productview/' . $list->ads_id)); ?>" class="nav-link"><i class="mdi mdi-eye"></i> </a></td>
                    <td><a href="<?php echo e(url('reportup/' . $list->report_id)); ?>" class="nav-link"><i class="mdi mdi-pen"></i> </a></td>
                    <td><a href="<?php echo e(url('adsdistroy/' . $list->ads_id)); ?>" class="nav-link"><i class="mdi mdi-delete"></i> </a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tbody>

                </tbody>
            </table>
        </div>
        <div class="mt-3 text-white">
            <?php echo e($ads->links()); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bikroy\resources\views/backend/ads/reportedads/reportedads.blade.php ENDPATH**/ ?>