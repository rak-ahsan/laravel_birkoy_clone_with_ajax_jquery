
<?php $__env->startSection('content'); ?>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">All Members</h4>
            </p>
            <table class="table table-bordered text-center">
                <thead>
                    <tr>
                        <th> # </th>
                        <th> Name </th>
                        <th> Email </th>
                        <th> Number </th>
                        <th> Payment </th>
                        <th> Membership </th>
                        <th> Joining Date </th>
                        <th colspan="3"> Action </th>
                    </tr>
                </thead>
                <?php
                $a=1
                ?>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($a++); ?> </td>
                    <td> <?php echo e($list->name); ?></td>
                    <td><?php echo e($list->email); ?> </td>
                    <td><?php echo e($list->number); ?> </td>
                    <td><?php echo e($list->paymentMethod); ?> </td>
                    <?php if($list->membership == 1): ?>
                        <td>Free</td>
                    <?php else: ?>
                    <td>Paid</td>
                    <?php endif; ?>
                    <td><?php echo e($list->created_at); ?> </td>

                    <td><a href="<?php echo e(url('/edit' , $list->username)); ?>" class="nav-link"><i
                        class="mdi mdi-pen"></i> </a></td>

                    <td><a href=" <?php echo e(route('userprofile',$list->username)); ?>" class="nav-link"><i
                                class="mdi mdi-eye"></i> </a></td>
                    <td><a href="<?php echo e(url('memberdelete/' . $list->mem_id)); ?>" class="nav-link"><i
                                class="mdi mdi-delete"></i> </a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tbody>

                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bikroy\resources\views/backend/user/pendinguser.blade.php ENDPATH**/ ?>