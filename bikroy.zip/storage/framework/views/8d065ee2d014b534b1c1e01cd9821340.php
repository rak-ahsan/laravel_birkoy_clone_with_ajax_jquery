<?php $__env->startSection('content'); ?>
<?php echo $__env->make('backend.user.membership', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container shadow mt-5" style="background-color: #FFFFFF">
    <div class="row">
        <div class="col-md-4" style="border-right: 1px solid rgb(200, 200, 200)">
            <div class="card mt-3 mb-5 justify-content-center" style="width: 18rem;">
                <img src="<?php echo e(asset('img/user/' . $user->user_img)); ?>" alt="" srcset="" class="img-fluid"
                    style="border-radius: 5px">
                <div class="card-body">
                    <h4 class="card-title"><b><?php echo e($user->name); ?></b></h4>
                    <div class="card-subtitle mb-2 text-body-secondary">
                        <?php if($user->membership == 2): ?>
                        <img src=" <?php echo e(asset ('img/memberbadge.png')); ?>" alt="" srcset="" class="img-fluid"
                            style="width:80px"><b>Paid Member</b>
                        <?php else: ?>
                        <img src=" <?php echo e(asset ('img/freemember.png')); ?>" alt="" srcset="" class="img-fluid"
                            style="width:80px"><b>Free Member</b>
                        <?php endif; ?>
                    </div>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">Member Since: <?php echo e(auth()->user()->created_at->format('F Y')); ?></li>
                    <li class="list-group-item">Phone Number : <?php echo e($user->number); ?></li>
                    <li class="list-group-item">Email Address : <?php echo e($user->email); ?></li>
                    <li class="list-group-item">Location: <?php echo e($user->loc_name); ?></li>

                    <?php if(Auth::user() && Auth::user()->id == $user->id && Auth::user()->membership == 1): ?>
                    <li class="list-group-item text-center">

                        <?php if($mem !==null && $mem->user_name == Auth::user()->username): ?>
                        <span>We've Recived Your Membership Request</span>
                        <?php else: ?>
                        <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal"
                            style="background-color: #ffc800">
                            Buy Membership Now
                        </button>
                        <?php endif; ?>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <!-- mainpart -->
        <?php
        $limit = App\Models\adslimit::first()
        ?>
        <div class="col-md-8 p-3">
            <div class="d-flex">
                <p><b>Adds Posted By <?php echo e($user->name); ?> <br>
                        <?php if(Auth::user() && Auth::user()->id == $user->id && Auth::user()->membership == 1): ?>
                        You're a freemember Your Ads Limits <?php echo e($limit->limit); ?> You Can Post <?php echo e($limit->limit - $adsnum); ?> more Ads </b></p>
                <?php endif; ?>
            </div>
            <h5 class="text-center">Active Ads</h5>

            <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="post">
                <a href="<?php echo e(url('productview/' . $list->ads_id)); ?>" class="nav-link">
                    <div class="card my-3">
                        <div class="row g-0 p-3">
                            <div class="col-md-4">
                                <img src="<?php echo e(asset('img/ads/' . $list->mainphoto)); ?>" class="img-fluid rounded-start"
                                    alt="..." style="height: 200px">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <?php echo e($list->title); ?></h5>
                                    <p class="card-text"> <?php echo e($list->loc_name); ?> , <?php echo e($list->cata_name); ?></p>
                                    <p class="card-text"><span style="color: #149777; font-size:20px ">Tk
                                            <?php echo e($list->price); ?></span></p>
                                </div>
                                <p class="text-end px-4"><?php echo \Carbon\Carbon::parse($list->created_at)->diffForHumans(); ?></p>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- pending -->
            <?php if(Auth::user()->id == $user->id ): ?>
            <h5 class="text-center">Pending Ads</h5>
            <?php $__currentLoopData = $pendingads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="post">
                <a href="<?php echo e(url('productview/' . $list->ads_id)); ?>" class="nav-link">
                    <div class="card my-3">
                        <div class="row g-0 p-3">
                            <div class="col-md-4">
                                <img src="<?php echo e(asset('img/ads/' . $list->mainphoto)); ?>" class="img-fluid rounded-start"
                                    alt="..." style="height: 200px">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <?php echo e($list->title); ?></h5>
                                    <p class="card-text"> <?php echo e($list->loc_name); ?> , <?php echo e($list->cata_name); ?></p>
                                    <p class="card-text"><span style="color: #149777; font-size:20px ">Tk
                                            <?php echo e($list->price); ?></span></p>
                                </div>
                                <p class="text-end px-4"><?php echo \Carbon\Carbon::parse($list->created_at)->diffForHumans(); ?></p>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php echo $__env->make('Frontend/layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layout.Head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bikroy\resources\views/Frontend/userprofile.blade.php ENDPATH**/ ?>