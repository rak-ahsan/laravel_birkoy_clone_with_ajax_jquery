<div class="post">

    <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <a href="<?php echo e(url('productview/' . $list->ads_id)); ?>" class="nav-link">
        <div class="card my-3">
            <div class="row g-0 p-3">
                <div class="col-md-4">
                    <img src="<?php echo e(asset('img/ads/' . $list->mainphoto)); ?>" class="img-fluid rounded-start"
                        alt="..." style="height: 200px">
                  </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title">
                            <?php echo e($list->title); ?></h5>
                        <p class="card-text"> <?php echo e($list->loc_name); ?> , <?php echo e($list->cata_name); ?></p>
                        <p class="card-text"><span style="color: #149777; font-size:20px ">Tk
                                <?php echo e($list->price); ?></span></p>
                    </div>
                    <p class="text-end px-4"><?php echo \Carbon\Carbon::parse($list->created_at)->diffForHumans(); ?></p>
                </div>
            </div>
        </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH D:\bikroy\resources\views/Frontend/layout/searchads.blade.php ENDPATH**/ ?>