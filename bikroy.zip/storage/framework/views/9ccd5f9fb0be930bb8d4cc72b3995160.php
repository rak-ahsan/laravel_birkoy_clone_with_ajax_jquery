
<?php $__env->startSection('content'); ?>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">All Ads</h4>
            </p>
            <table class="table table-bordered text-center">
                <thead>
                    <tr>
                        <th> # </th>
                        <th> Ads Title </th>
                        <th> Ads Price </th>
                        <th> Number </th>
                        <th> Membership </th>
                        <th> Posting Date </th>
                        <th colspan="3"> Action </th>
                    </tr>
                </thead>
                <?php
                $a=1
                ?>
                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($a++); ?> </td>
                    <td> <?php echo e($list->title); ?></td>
                    <td><?php echo e($list->price); ?> </td>
                    <td><?php echo e($list->pos_number); ?> </td>
                    <td> free </td>
                    <td><?php echo e($list->created_at); ?> </td>
                    <td><a href="<?php echo e(url('editads/' . $list->ads_id)); ?>" class="nav-link"><i class="mdi mdi-pen"></i> </a></td>
                    <td><a href="<?php echo e(url('productview/' . $list->ads_id)); ?>" class="nav-link"><i class="mdi mdi-eye"></i> </a></td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tbody>

                </tbody>
            </table>
        </div>
        <div class="mt-3 text-white">
            <?php echo e($ads->links()); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bikroy\resources\views/backend/ads/pendingads.blade.php ENDPATH**/ ?>