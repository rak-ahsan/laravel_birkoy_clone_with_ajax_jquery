
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <button type="button" class="btn btn-info btn-fw" data-bs-toggle="modal" data-bs-target="#exampleModal">ADD
            Categories</button>
        <table class="table table-hover text-center">
            <thead>
                <tr>
                    <th>Catagory Name</th>
                    <th>Catagory Icon</th>
                    <th>User Name</th>
                    <th colspan="2">Action</th>
                </tr>
            </thead>
            <?php if($catagory->isNotEmpty()): ?>
            <tbody>
                <?php $__currentLoopData = $catagory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($row->cata_name); ?></td>
                    <td><?php echo e($row->cata_icon); ?></td>
                    <td><?php echo e($row->cata_username); ?></td>
                    <td> <a class="nav-link edit" data-id="<?php echo e($row->cata_id); ?>" data-bs-toggle="modal"
                            data-bs-target="#exampleModals"><i class="mdi mdi-lead-pencil
                        "></i></a></td>
                    <td><a class="nav-link" href="<?php echo e(route('category.destroy', $row->cata_id)); ?>"><i class="mdi mdi-delete

                        "></i></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center">
                        <h2>Sorry No Record Found</h2>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="mt-3 text-white">
            <?php echo e($catagory->links()); ?>

        </div>
    </div>
</div>

<?php echo $__env->make('backend.catagories.categorycreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"
    integrity="sha512-3gJwYpMe3QewGELv8k/BX9vcqhryRdzRMxVfq6ngyWXwo03GFEzjsUm8Q7RZcHPHksttq7/GFoxjCVUjkjvPdw=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $(document).ready(function () {
        $(".edit").click(function (e) {
            e.preventDefault();
            var cata_id = $(this).attr("data-id");
            $.ajax({
                type: "GET",
                url: "category/" + cata_id + "/edit",
                data: {
                    cata_id: cata_id
                },
                success: function (response) {
                    $('.modal-body').html(response);
                    $('#exampleModal').modal('show');
                }
            });
        });
    });

</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bikroy\resources\views/backend/catagories/catagoryview.blade.php ENDPATH**/ ?>