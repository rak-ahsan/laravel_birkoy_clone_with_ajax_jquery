
<?php $__env->startSection('content'); ?>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="container">
        <form class="forms-sample mt-3" id="from" action="<?php echo e(route('reportups', $ads->report_id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="form-group">
                <label for="exampleInputUsername1">Report Details</label>
                <input type="text" class="form-control" id="cata_name" placeholder="Category Name" name="reports"
                    value="<?php echo e($ads->reports); ?>">
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Status</label>
                <select class="form-select" aria-label="Default select example" name="status" style="font-size: 0.8125rem">
                    <option selected>Open this select menu</option>
                    <option value="0"  <?php echo e(0 == $ads->status ? 'selected' : ''); ?>>Pending</option>
                    <option value="1"  <?php echo e(1 == $ads->status ? 'selected' : ''); ?>>Resolved</option>
                </select>
            </div>
            <button type="submit" class="btn btn-gradient-primary me-2" id="sub">Submit</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bikroy\resources\views/backend/ads/reportedads/reportup.blade.php ENDPATH**/ ?>