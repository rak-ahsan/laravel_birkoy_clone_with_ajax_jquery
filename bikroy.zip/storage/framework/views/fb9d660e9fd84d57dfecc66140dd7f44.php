<?php $__env->startSection('content'); ?>
<div class="container shadow mt-5" style="background-color: #FFFFFF">
<!-- 
    <div class="row">
        <div class="banner col-md-12">
            <img src=" <?php echo e(asset ('img/banner.jpg')); ?>" alt="" srcset="" class="img-fluid">
        </div>
    </div> -->
    <div class="row">
        <!-- sidebar -->
        
        <div class="col-md-4" style="border-right: 1px solid rgb(200, 200, 200)">
        <div class="dp col-md-4">
        <img src="<?php echo e(asset('img/user/' . Auth::user()->user_img)); ?>" alt="" srcset="" class="img-thumbnail">
        </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item"><h2><?php echo e(Auth::user()->name); ?> </h2></li>
                <li class="list-group-item"><h5><?php echo e(Auth::user()->number); ?></h5></li>
                <li class="list-group-item"><h5><?php echo e(Auth::user()->location); ?></h5></li>
                <li class="list-group-item"><h5><?php echo e(Auth::user()->email); ?></h5></li>
            </ul>
        </div>
        <!-- mainpart -->
        <div class="col-md-8 p-3">
            <p><b>Adds Posted By Rakib</b></p>
            <div class="post">
                <a href="<?php echo e('productview'); ?>" class="nav-link">
                    <div class="card my-3">
                        <div class="row g-0 p-3">
                            <div class="col-md-4">
                                <img src="<?php echo e('img/laptop.jpg'); ?>" class="img-fluid rounded-start" alt="...">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        Emergency PC sell post</h5>
                                    <p class="card-text"> Kushtia, Khulna Division</p>
                                    <p class="card-text"><small class="text-body-secondary">2500</small></p>
                                </div>
                                <p class="text-end px-4">10 ministes ago</p>
                            </div>
                        </div>
                    </div>
                </a>
                <div class="card my-3">
                    <div class="row g-0 p-3">
                        <div class="col-md-4">
                            <img src="<?php echo e('img/laptop.jpg'); ?>" class="img-fluid rounded-start" alt="...">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title">
                                    Emergency PC sell post</h5>
                                <p class="card-text"> Kushtia, Khulna Division</p>
                                <p class="card-text"><small class="text-body-secondary">2500</small></p>
                            </div>
                            <p class="text-end px-4">10 ministes ago</p>
                        </div>
                    </div>
                </div>
                <div class="card my-3">
                    <div class="row g-0 p-3">
                        <div class="col-md-4">
                            <img src="<?php echo e('img/laptop.jpg'); ?>" class="img-fluid rounded-start" alt="...">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title">
                                    Emergency PC sell post</h5>
                                <p class="card-text"> Kushtia, Khulna Division</p>
                                <p class="card-text"><small class="text-body-secondary">2500</small></p>
                            </div>
                            <p class="text-end px-4">10 ministes ago</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php echo $__env->make('Frontend/layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.layout.Head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bikroy\resources\views/dashboard.blade.php ENDPATH**/ ?>