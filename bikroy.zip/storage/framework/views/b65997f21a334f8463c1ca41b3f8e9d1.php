 <?php $__env->startSection('content'); ?>
<div class="container mt-5 shadow" style="background-color:#fff;">
    <div class="row justify-content-center align-items-center">
        <div class="col-md-4 p-3">
            <div class="col"><b>My Chats</b></div>
            <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(Auth::user()->username == $chat->sender || Auth::user()->username == $chat->reciver && Auth::user()->username == $chat->user_name): ?>
            <?php if(Auth::user()->username !== $chat->sender): ?>
            <a id="la" class="nav-link" href="<?php echo e(route('message', [$chat->product_id, $chat->sender])); ?>">
                <div class="col d-flex mt-3 align-items-center">
                    <div class="img col-md-2"><img src="<?php echo e(asset('img/ads/'.$chat->mainphoto)); ?>"
                            style="height: 50px; width:50px; border-radius:50%"></div>
                    <div class="des col-md-10 px-2"><b><?php echo e($chat->title); ?> <br><small> <?php echo e($chat->sender); ?></small>d</b></div>
                </div>
            </a>
            <?php elseif(Auth::user()->username == $chat->user_name): ?>
            <?php else: ?>
            <a id="la" class="nav-link" href="<?php echo e(route('message', [$chat->product_id, $chat->reciver])); ?>">
                <div class="col d-flex mt-3 align-items-center">
                    <div class="img col-md-2"><img src="<?php echo e(asset('img/ads/'.$chat->mainphoto)); ?>"
                            style="height: 50px; width:50px; border-radius:50%"></div>
                    <div class="des col-md-10 px-2"><b><?php echo e($chat->title); ?> <br> <small><?php echo e($chat->reciver); ?></small></b></div>
                </div>
            </a>
            <?php endif; ?>
                
            <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="col-md-8">
            <p>Please Follow Our Policy while Chatting</p>
        </div>
    </div>
</div>
<?php echo $__env->make('Frontend/layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"
    integrity="sha512-3gJwYpMe3QewGELv8k/BX9vcqhryRdzRMxVfq6ngyWXwo03GFEzjsUm8Q7RZcHPHksttq7/GFoxjCVUjkjvPdw=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layout.Head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bikroy\resources\views/Frontend/chatlist.blade.php ENDPATH**/ ?>